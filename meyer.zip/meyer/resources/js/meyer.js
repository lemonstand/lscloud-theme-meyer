'use strict';

/**
 * @ngdoc overview
 * @name lsAngularApp
 * @description
 * # lsAngularApp
 *
 * Main module of the application.
 */
angular
  .module('lsAngularApp', [
    'ngAnimate',
    'ngAria',
    'ngMessages',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngMaterial'
  ])
  .config(function($interpolateProvider,$locationProvider) {
    $interpolateProvider.startSymbol('[[');
    $interpolateProvider.endSymbol(']]');
  })
  .run(function(ThemeService,$rootScope,$window,$timeout){
    $rootScope.$ls = $window.localStorage;
    ThemeService.get().then(function(results){
      $rootScope.$theme = results.data;
      $rootScope.$emit('themeLoaded');
    });
    $rootScope.date = new Date();
    $rootScope.compiled = [];
    $rootScope.loadingScreen = false;
    $rootScope.showLoadingScreen = function(){ $rootScope.loadingScreen = true; };
    $rootScope.hideLoadingScreen = function(){ $rootScope.loadingScreen = false; $rootScope.$apply(); };
    $(window).on('onAfterAjaxUpdate onAjaxSuccess onAjaxFailure', function(e){
      $rootScope.hideLoadingScreen();
    });


    var flashDelay;
    $rootScope.hideFlash = function(delay){
      $timeout.cancel(flashDelay);
      flashDelay = $timeout(function(){
        $rootScope.showFlash = false;
        $timeout(function(){
          $rootScope.flashMessage = null;
        },800);
      },delay);
    };

    $window.flash = function(message,delay){
      if (message.length){
        delay = typeof delay !== 'undefined' ? delay : 10000;
        $rootScope.showFlash = true;
        console.log(delay, message);
        $rootScope.flashMessage = message;
        $rootScope.$apply();
        $rootScope.hideFlash(delay);
      }
    };

  });



/**
 * @ngdoc function
 * @name lsAngularApp.controller:HomeCtrl
 * @description
 * # HomeCtrl
 * Controller of the lsAngularApp
 */
angular.module('lsAngularApp')
  .controller('HomeCtrl', function ($scope,ThemeService, CategoryService, ProductService,$timeout) {

    //variables
    $scope.productListLimit = 5;
    $scope.blogPostLimit = 4;


    //services
    ThemeService.get().then(function(results){
      $scope.banner = results.data.banner;
      $scope.banner.button.text = 'Learn more';
    });

    $scope.categories = [];
    CategoryService.all().then(function(results){
      angular.forEach(results.data.categories, function(category){
        $timeout(function(){
          $scope.categories.push(category);
        },100);
      });
    });

    $scope.productList = [];
    ProductService.featured().then(function(results){
      angular.forEach(results.data.products, function(product){
        $timeout(function(){
          $scope.productList.push(product);
        },100);
      });
    });
  });



 /**
  * @ngdoc function
  * @name lsAngularApp.controller:NavCtrl
  * @description
  * # NavCtrl
  * Controller of the lsAngularApp
  */

angular.module('lsAngularApp')
  .controller('NavCtrl', function ($rootScope,$scope,$filter,CartService,ProductService,CategoryService,$q,$timeout,$mdSidenav) {
      var getCurrentNavItem = function(){
        var path = window.location.pathname.slice(1).split('/')[0];
        if (path === 'categories' ||  path === 'product' || path === 'products'){
          $scope.currentNavItem = 'products';
        }
        else if ( !path ) {
          $scope.currentNavItem = 'home';
        }
        else {
          $scope.currentNavItem = path;
        }
      };
      getCurrentNavItem();

      $scope.openSideNav = function(navID){
        $mdSidenav(navID).open();
      };
      $scope.closeSidenav = function(navID){
        $mdSidenav(navID).close();
      };

      var originatorEv;
      $scope.openMenu = function($mdOpenMenu, $event) {
        originatorEv = $event;
        $mdOpenMenu($event);
      };

      CategoryService.all().then(function(results){
        $scope.categories = $filter('arrayColumns')( results.data.categories, 4 );
      });

      $rootScope.categoryViewActive = false;

      $rootScope.toggleCategoryView = function(){
        $rootScope.categoryViewActive = !$rootScope.categoryViewActive;
      };

      $rootScope.$on('$routeChangeStart', function(){
        $rootScope.categoryViewActive = false;
      });

      $rootScope.$on('cartUpdated', function(event,cart){
        $scope.cart = cart;
      });

      $scope.favourites = CartService.favourites();
      $scope.cart = CartService.cart();


      $rootScope.addFavourite = function(product){
        CartService.addFavourite(product).then(function(favs){
          $scope.favourites = favs;
        });
      };

      $rootScope.removeFavourite = function(product){
        CartService.removeFavourite(product).then(function(favs){
          $scope.favourites = favs;
        });
      };

      $rootScope.isFavourite = function(product){
        var favs = CartService.favourites();
        var isFav = $filter('filter')( favs, {'id': product.id}, true).length >= 1 ? true : false;
        return isFav;
      };

      $rootScope.removeFromCart = function(product){
        CartService.removeFromCart(product).then(function(){
          product.in_cart = false;
        });
      };

      $rootScope.addToCart = function(product){
        CartService.addToCart(product).then(function(){
          product.in_cart = true;
        });
      };

      ProductService.all().then(function(results){
        $scope.products = results.data.products;
      });


      $scope.searchText = '';

      $scope.querySearch = function(query) {
        var deferred = $q.defer();
        var results = $filter('filter')( $scope.products, { 'name':  query } );
        $timeout(function(){
          deferred.resolve(results);
        },Math.random() * 1000, false);
        return deferred.promise;
      };

    });


/**
 * @ngdoc service
 * @name lsAngularApp.global
 * @description
 * # global
 * Constants in the lsAngularApp.
 */
angular.module('lsAngularApp')
  .constant('LEMONSTAND', (function(){
    var resource = 'https://'+ window.location.hostname +'/api';
    return {
      RESOURCE: resource,
      PRODUCTS: resource + '/products/',
      FEATURED: resource + '/products/featured/',
      CATEGORIES: resource + '/categories/',
      THEME: resource + '/theme/',
      BLOG: resource + '/blog/'
    };
  })());

  window.indexOfObject = function(arr, obj){
    for(var i = 0; i < arr.length; i++){
        if(angular.equals(arr[i], obj)){
            return i;
        }
    }
    return -1;
  };



/**
 * @ngdoc service
 * @name lsAngularApp.ThemeService
 * @description
 * # ThemeService
 * Service in the lsAngularApp.
 */
angular.module('lsAngularApp')
  .service('ThemeService', function ($http, $q, LEMONSTAND) {
    this.get = function(){
      return $http.get(LEMONSTAND.THEME);
    };
  });



/**
 * @ngdoc service
 * @name lsAngularApp.CategoryService
 * @description
 * # CategoryService
 * Service in the lsAngularApp.
 */
angular.module('lsAngularApp')
  .service('CategoryService', function ($http, $q, LEMONSTAND,$filter) {

    this.all = function(){
      if ( typeof categories !== 'undefined' ){
        var deferred = $q.defer();
        var results = { data: categories };
        deferred.resolve(results);
        return deferred.promise;
      }
      else {
        return $http.get(LEMONSTAND.CATEGORIES);
      }
    };

    // this.get = function(slug){
    //   return $http.get(LEMONSTAND.CATEGORIES + slug);
    // };

    this.get = function(slug,forceAjax){
      if ( typeof categories !== 'undefined' && !forceAjax ){
        var deferred = $q.defer();
        var category = $filter('filter')( categories.categories, { 'url_name': slug }, true )[0];
        var results = { data: category };
        deferred.resolve(results);
        return deferred.promise;
      }
      else {
        return $http.get(LEMONSTAND.CATEGORIES + slug);
      }
    };

  });



/**
 * @ngdoc service
 * @name lsAngularApp.ProductService
 * @description
 * # ProductService
 * Service in the lsAngularApp.
 */
angular.module('lsAngularApp')
  .service('ProductService', function ($http, $q, LEMONSTAND) {

    this.all = function(){
      if ( typeof products !== 'undefined' ){
        var deferred = $q.defer();
        var results = { data: products };
        deferred.resolve(results);
        return deferred.promise;
      }
      else {
        return $http.get(LEMONSTAND.PRODUCTS);
      }
    };

    this.category = function(){
      if ( typeof categoryProducts !== 'undefined' ){
        var deferred = $q.defer();
        var results = { data: categoryProducts };
        deferred.resolve(results);
        return deferred.promise;
      }
      else {
        return $http.get(LEMONSTAND.PRODUCTS);
      }
    };

    this.get = function(slug){
      return $http.get(LEMONSTAND.PRODUCTS + slug);
    };

    this.featured = function(page){
      if( typeof featuredProducts !== 'undefined' ){
        var deferred = $q.defer();
        var results = { data: featuredProducts };
        deferred.resolve(results);
        return deferred.promise;
      }
      else {
        page = angular.isUndefined(page) ? 1 : page;
        return $http.get(LEMONSTAND.FEATURED + page);
      }
    };

  });



  /**
   * @ngdoc service
   * @name lsAngularApp.BlogService
   * @description
   * # BlogService
   * Service in the lsAngularApp.
   */
  angular.module('lsAngularApp')
    .service('BlogService', function ($http, $q, LEMONSTAND) {

      this.all = function(){
        if ( typeof blogPosts !== 'undefined' ){
          var deferred = $q.defer();
          var results = { data: blogPosts };
          deferred.resolve(results);
          return deferred.promise;
        }
        else {
          return $http.get(LEMONSTAND.BLOG);
        }
      };

    });




/**
 * @ngdoc filter
 * @name lsAngularApp.filter:moment
 * @function
 * @description
 * # moment
 * Filter in the lsAngularApp.
 */
angular.module('lsAngularApp')
  .filter('moment', function () {
    return function (date) {
      var moment = window.moment;
      date = new Date(date);
      moment.updateLocale('en', {
          relativeTime : {
            d : 'yesterday'
          }
      });
      var ago = moment(date).fromNow(true);
      ago += ago.indexOf('yesterday') !== -1 ? ' at '+moment(date).format('hh:mm') : ' ago';
      return ago;
    };
  });



/**
 * @ngdoc filter
 * @name lsAngularApp.filter:capitalize
 * @function
 * @description
 * # capitalize
 * Filter in the lsAngularApp.
 */
angular.module('lsAngularApp')
  .filter('capitalize', function () {
    return function (input) {
      return input.charAt(0).toUpperCase() + input.slice(1);
    };
  });



/**
 * @ngdoc service
 * @name lsAngularApp.MailChimpService
 * @description
 * # MailChimpService
 * Service in the lsAngularApp.
 */
angular.module('lsAngularApp')
  .service('MailChimpService', function ($http,$rootScope) {

    this.add = function(email){
      var MailChimp = {
        dc: $rootScope.$theme.mailchimp.api_key.split('-')[1],
        uri: '.api.mailchimp.com/2.0',
        api_key: $rootScope.$theme.mailchimp.api_key,
        list_id: $rootScope.$theme.mailchimp.list_id
      };
      return $http.post('https://' + MailChimp.dc + MailChimp.uri  +'/lists/subscribe?apikey='+ MailChimp.api_key + '&id='+ MailChimp.list_id +'&email[email]='+email);
    };
  });



/**
 * @ngdoc directive
 * @name lsAngularApp.directive:mailchimp
 * @description
 * # mailchimp
 */
angular.module('lsAngularApp')
  .controller('MailChimpCtrl', function (MailChimpService,$timeout,$scope) {

      $scope.resetForm = function(form){
        form.$setPristine();
        form.$setUntouched();
      };

      $scope.mailchimpAdd = function(form){
        if (form.honey.$touched){
          form.email_address.$error.unknown = true;
        }
        else if (form.$valid){
          MailChimpService.add($scope.mailchimp_email).then(function(result){
            if (result.status === 200){
              form.email_address.$error.success = true;
              $timeout(function(){ $scope.resetForm(form); $scope.mailchimp_email = ''; },10000);
            }
            else { form.email_address.$error.unknown = true; }
          }, function(err){
            if (err.data.code === 214){ form.email_address.$error.exists = true; }
            else { form.email_address.$error.unknown = true; }
          });
        }
      };
  });



/**
 * @ngdoc controller
 * @name lsAngularApp.controller:FooterCtrl
 * @description
 * # FooterCtrl
 */
angular.module('lsAngularApp')
  .controller('FooterCtrl', function ($scope,InstagramService,$rootScope) {
    $scope.date = new Date();
    // $rootScope.$on('themeLoaded', function(e){
    //   InstagramService.get($rootScope.$theme.social.ig_token).success(function(results){
    //     $scope.instagram = results.data;
    //   });
    //
    // });
  });



/**
 * @ngdoc service
 * @name lsAngularApp.InstagramService
 * @description
 * # InstagramService
 * Service in the lsAngularApp.
 */
angular.module('lsAngularApp')
  .service('InstagramService', function ($http) {
    this.get = function(auth){

        return $http({
                method: 'JSONP',
                url: 'https://api.instagram.com/v1/users/self/media/recent/?callback=JSON_CALLBACK&access_token=' + auth,
                params: {
                    format: 'jsonp',
                    json_callback: 'JSON_CALLBACK'
                }
            })

    };
  });



/**
 * @ngdoc filter
 * @name lsAngularApp.filter:arrayColumns
 * @function
 * @description
 * # arrayColumns
 * Filter in the lsAngularApp.
 */
angular.module('lsAngularApp')
  .filter('arrayColumns', function () {
    return function (input,cols) {
      var arr = [];
      for(var i = 0; i < input.length; i++) {
        var colIdx = i % cols;
        arr[colIdx] = arr[colIdx] || [];
        arr[colIdx].push(input[i]);
      }
      return arr;
    };
  });



/**
 * @ngdoc function
 * @name lsAngularApp.controller:CategoriesCtrl
 * @description
 * # CategoriesCtrl
 * Controller of the lsAngularApp
 */
angular.module('lsAngularApp')
  .controller('CategoriesCtrl', function ($scope,CategoryService,$filter,$timeout,ProductService) {
    var browsing = false;
    var windowParams = {};
    if (window.location.search) {
        var parts = window.location.search.substring(1).split('&');
        for (var i = 0; i < parts.length; i++) {
            var nv = parts[i].split('=');
            if (!nv[0]) continue;
            windowParams[nv[0]] = nv[1] || true;
        }
    }
    $route.current.params.category = !angular.isUndefined( windowParams.category ) ? windowParams.category : null;
    $route.current.params.brand = !angular.isUndefined( windowParams.brand ) ? windowParams.brand : null;
    $scope.productsLoading = true;

    //hero banner for parent category
    // var updateBanner = function(result){
    //   console.log(result);
    //   $scope.banner = {
    //     image: result.data.images[ result.data.images.length > 1 ? 1 : 0 ],
    //     title: result.data.name,
    //     text: result.data.short_description,
    //     short: true //not as big as the home page
    //   };
    // };

    /**
      Set the product list limit on load
      # Get from localstorage if it exists; if not, default is 6
      # On load, paginate all of that category's items
     */
    $scope.productListLimit = Number($scope.$ls.productPageListLimit ? $scope.$ls.productPageListLimit : 6);
    $scope.setProductLimit = function(int){
      $scope.productListLimit = int;
      $scope.$ls.productPageListLimit = int;
    };

    $scope.filters = {
      category: {
        parent: $route.current.params.parentCategory,
        child: !angular.isUndefined($route.current.params.category) ? $route.current.params.category : null
      },
      price: null,
      brand: $route.current.params.brand ? $route.current.params.brand : null,
      search: null,
      sale: false,
      limit: $scope.productListLimit
    };

    $scope.resetFilters = function(){
      $scope.filters.price = null;
      $scope.filters.brand = null;
      $scope.displayBrand = null;
      $scope.filters.search = null;
      $scope.filters.sale = false;
    }

    $scope.saleItemsOnly = function(){
      $scope.filters.price = null;
      $scope.filters.brand = null;
      $scope.filters.search = null;
      $scope.filters.sale = true;
    };

    var setProducts = function(results){
      if (results.data.products.length){
        var maxPrice = Math.ceil($filter('orderBy')( results.data.products, 'price', true )[0].price /100)*100;
        $scope.priceFilter = {
          max: maxPrice,
          min: 0
        };
        $scope.filters.price = maxPrice;
        //add to the `brands` array using the indexOfObject global function
        angular.forEach( results.data.products, function(product){
          var manufacturer = { name: product.manufacturer, slug: product.manufacturer.replace(/ /g, '-').toLowerCase(), url_name: product.manufacturer_url };
          if (window.indexOfObject( $scope.brands, manufacturer) === -1 ){ $scope.brands.push(manufacturer); }
        });
        $scope.brands = $filter('orderBy')( $scope.brands, 'slug' ); //order alphabetically
      }
      $scope.categoryProducts = results.data.products;
      $scope.updateFilter();
    };

    $scope.$watch('filters.brand',function(newBrand,oldBrand){
      if (newBrand !== oldBrand){ browsing = true; }
    });

    var categoryInit = function(parent,child){
      $scope.brands = [];
      if (angular.isUndefined($scope.productCategories)) {
        getAllCategories(parent);
      }
      else {
        updateProductMenuTile(parent); //fetch and define categories if not done
      }
      //update filters
      $scope.filters.category.parent = parent;
      $scope.filters.category.child = child;
      $scope.filters.brand = null;
      $scope.activeFilter = $scope.filters.category.child ? $scope.filters.category.child : $scope.filters.category.parent;
    };

    $scope.categoryProducts = [];
    $scope.getCategoryProducts = function(parent,child){
      $scope.productsLoading = true;
      if ( parent === $route.current.params.parentCategory ){
        CategoryService.get(parent).then(function(results){
          categoryInit(parent,child);
          ProductService.category().then(function(categoryResults){
            setProducts(categoryResults);
          });
        });
      }
      else {
        CategoryService.get(parent,true).then(function(results){
          categoryInit(parent,child);
          setProducts(results);
        });
      }
    };

    $scope.getAllProducts = function(){
      $scope.productsLoading = true;
      ProductService.all().then(function(results){
        $scope.brands = [];
        getAllCategories();

        //update filters
        $scope.filters.brand = $route.current.params.brand ? $route.current.params.brand : null;
        $scope.currentCategory = { name: 'Categories' };
        setProducts(results);
      });
    };

    if(!angular.isUndefined($scope.filters.category.parent) && $scope.filters.category.parent !== null){
      $scope.getCategoryProducts($scope.filters.category.parent, $scope.filters.category.child);
    }
    else {
      $scope.getAllProducts();
    }

    $scope.updateFilter = function(){
      var products = $scope.categoryProducts;

      //filter by search term
      if ($scope.filters.search){
        products = $filter('filter')( products, { 'name': $scope.filters.search });
      }

      //filter by category
      var category = $scope.filters.category.child ? $scope.filters.category.child : $scope.filters.category.parent;
      if (category){
        products = $filter('filter')( products, { 'categories': category } );
      }

      //filter by price
      if ($scope.filters.price){
        products = $filter('priceRange')( products, $scope.filters.price );
      }

      //filter by brand
      if ( $scope.filters.brand ){
        products = $filter('filter')(products, { 'manufacturer_url': $scope.filters.brand }, true);
      }

      //filter by sale items
      if ($scope.filters.sale ){
        products = $filter('filter')(products, { 'on_sale': true }, true);
      }

      //paginate them
      $scope.pagination(products);
      $scope.filteredProducts = products;
    };

    $scope.$watch('filters', function(newFilters,oldFilters){
      if (newFilters !== oldFilters){
        $scope.activeFilter = $scope.filters.category.child ? $scope.filters.category.child : $scope.filters.category.parent;
        $scope.updateFilter();
      }
    },true);


    var updateProductMenuTile = function(parent){
      $scope.currentCategory = $filter('filter')($scope.productCategories, { 'url_name': parent },true)[0];
      $scope.childCategories = $scope.currentCategory.children;
    };

    var getAllCategories = function(parent){
      //big list of all categories for dropdown menu
      CategoryService.all().then(function(results){
        $scope.productCategories = results.data.categories;
        if (!angular.isUndefined(parent)){
          updateProductMenuTile(parent);
        }
      });
    };


    $scope.$watch('productListLimit', function(newVal,oldVal){
      if (newVal !== oldVal){ $scope.pagination($scope.productList); }
    });

    //get the products filtered by category, then paginate them on the front-end
    $scope.pagination = function(products){
      var pages = Math.ceil(products.length / $scope.productListLimit); //how many pages?
      $scope.newHeight(); //sets a min height of the container so it doesn't look weird
      $scope.pages = new Array(pages);
      $scope.goToPage(1,products);
    };

    //pagination navigation across the nation
    $scope.goToPage = function(page,products){
      $scope.currentPage = page;
      var start = (page - 1) * $scope.productListLimit;
      var end = ((page - 1) * $scope.productListLimit) + $scope.productListLimit;
      $scope.productList = [];
      $timeout(function(){
        $scope.productsLoading = false;
        if ($scope.filters.brand){
          var brandName = $filter('filter')( $scope.brands, { url_name: $scope.filters.brand }, true );
          $scope.displayBrand = brandName.length ? brandName[0].name : null;
        }
        $scope.productList = products.slice(start,end);
      },400);
    };

  });



/**
 * @ngdoc filter
 * @name lsAngularApp.filter:priceRange
 * @function
 * @description
 * # priceRange
 * Filter in the lsAngularApp.
 */
angular.module('lsAngularApp')
  .filter('priceRange', function () {
    return function (products,maxPrice) {
      if (maxPrice){
        var filteredItems = [];
        angular.forEach(products, function(product){
          if ( Number(product.price) <= maxPrice ){
            filteredItems.push(product);
          }
        });
        return filteredItems;
      }
      else {
        return products;
      }
    };
  });



/**
 * @ngdoc directive
 * @name lsAngularApp.directive:minHeight
 * @description
 * # minHeight
 */
angular.module('lsAngularApp')
  .directive('minHeight', function ($timeout, $mdMedia) {
    return {
      restrict: 'A',
      link: function postLink(scope, element) {

        element.addClass('new-height-transition');

        scope.newHeight = function(){
          if (!$mdMedia('xs') && !$mdMedia('sm')){
            angular.element(element)[0].style.minHeight = 0;
            $timeout(function(){
              var currentHeight = element[0].clientHeight;
              angular.element(element)[0].style.minHeight = currentHeight+'px';
            },1000);
          }
        };

      }
    };
  });


/**
 * @ngdoc function
 * @name lsAngularApp.controller:ReviewDialogController
 * @description
 * # ReviewDialogController
 * Controller of the lsAngularApp
 */
  function ReviewDialogController($scope, $mdDialog) {
    $scope.hide = function() {
      $mdDialog.hide();
    };

    $scope.cancel = function() {
      $mdDialog.cancel();
    };

    $scope.submit = function(review) {
      $mdDialog.hide(review);
    };
  };

/**
 * @ngdoc function
 * @name lsAngularApp.controller:ProductCtrl
 * @description
 * # ProductCtrl
 * Controller of the lsAngularApp
 */
angular.module('lsAngularApp')
  .controller('ProductCtrl', function ($scope,ProductService,CartService,$filter,$window,$timeout,$http,$mdDialog) {
    var slug = $route.current.params.slug;

    $scope.writeReview = function(ev) {
      $mdDialog.show({
        controller: ReviewDialogController,
        template: reviewDialog, //passed in from Twig
        parent: angular.element(document.body),
        targetEvent: ev,
        clickOutsideToClose:true
      });
    };

    $scope.current = $window.location.href;

    $scope.carouselIndex = 0;
    $scope.changeCarousel = function(index){
      $scope.carouselIndex = index;
    };

    $scope.options = {};
    $scope.changeOption = function(id,value){
      $timeout(function(){
        $scope.options[id] = value;
      },50);
    };


    angular.forEach(reviews, function(review, index){
      var rating = review.item_rating.split('/');
      reviews[index].item_rating = Number(rating[0].trim());
    });
    $scope.customerReviews = reviews;
    $scope.currentReview = 0;


    ProductService.get(slug).then(function(result){
      $scope.product = result.data.product;
      $scope.product.favourite = CartService.isFavourite($scope.product);
      $scope.order = {
        id: $scope.product.id,
        name: $scope.product.name,
        images: $scope.product.images,
        short_description: $scope.product.short_description,
        price: $scope.product.price,
        on_sale: $scope.product.is_on_sale,
        discount: $scope.product.sale_price_or_discount,
        in_cart: CartService.isInCart(  {product: $scope.product } ),
        thumbnail: $scope.product.thumbnail,
        extras:{},
        quantity: (productQty ? productQty : 1)
      };
      angular.forEach($scope.product.options, function(option){
        $scope.order[option.name.toLowerCase()] = option.values[0]; //select the first option as the value
      });
    });

  });



  /**
   * @ngdoc function
   * @name lsAngularApp.controller:BlogCtrl
   * @description
   * # BlogCtrl
   * Controller of the lsAngularApp
   */
  angular.module('lsAngularApp')
    .controller('BlogCtrl', function ($scope,$timeout,BlogService) {

      BlogService.all().then(function(results){
        $scope.blog = results.data.blog;
        $scope.categories = [];
        $scope.months = [];
        var dates = [];

        angular.forEach($scope.blog, function(post, index){
            var d = Date.parse(post.publish_date);
            d = new Date(d);
            var month = d.getMonth();
            var year = d.getFullYear();
            var date = month+'/01/'+year;
            if (dates.indexOf(date) === -1){
              dates.push(date);
              $scope.months.push(new Date(date));
            }
            angular.forEach(post.categories, function(category, index){
              if ( $scope.categories.indexOf(category) === -1 ){
                $scope.categories.push(category);
              }
            })
        });
      });
    });



/**
 * @ngdoc function
 * @name lsAngularApp.controller:CartCtrl
 * @description
 * # CartCtrl
 * Controller of the lsAngularApp
 */
angular.module('lsAngularApp')
  .controller('CartCtrl', function ($scope,CartService) {
    $scope.items = {};
    //
    // CartService.getLsCart().then(function(results){
    //   // cart results
    // });
  });


/**
 * @ngdoc function
 * @name lsAngularApp.controller:CheckoutCtrl
 * @description
 * # CheckoutCtrl
 * Controller of the lsAngularApp
 */
angular.module('lsAngularApp')
  .controller('CheckoutCtrl', function ($scope,$timeout,$compile,$rootScope) {

    $(document).on('change', '#payment_method', function() {
      $rootScope.showLoadingScreen();
      $rootScope.$apply();

      $(this).sendRequest('shop:onUpdatePaymentMethod', {
        update: {'#payment_form' : 'partial-paymentform'},
        onAfterUpdate: function(e){
          $('#payment_form input[type=submit]').addClass('md-button ls-button ls-button-wide md-cornered no-margin md-ink-ripple').val('Complete order');
        },
      });
    });

    $scope.nextStep = function(){
      $(window).on('onAfterAjaxUpdate', function(e){
        if (typeof $('#checkout-page')[0] !== 'undefined'){
          $compile($('#checkout-page').contents())($scope);
          $scope.$digest();
        }
      });
    }

    //nothing to see here, move along
    $scope.shipping = {};
    $scope.billing = {};
    $scope.infoCopied = false;

    $scope.getValue = function(model,elem){
      $scope[model+'_name'] = $(elem+ ' option:selected').text().trim();
    };

    $scope.copyBillingInfo = function(){
      $scope.infoCopied = !$scope.infoCopied;
      if ($scope.infoCopied){
        $timeout(function(){
          var copied = angular.copy($scope.billing);
          $scope.shippingIsBilling = true;
          $scope.shipping = copied;
        });
      }
      else {
        $scope.shipping = {};
        $scope.shippingIsBilling = false;
      }
    }
  });



/**
 * @ngdoc directive
 * @name lsAngularApp.directive:compileOnChange
 * @description
 * # compileOnChange
 */
angular.module('lsAngularApp')
  .directive('compileOnChange', function ($window,$compile,$timeout) {
    return {
      restrict: 'A',
      link: function(scope,element,attrs){
        element.on('change', function(){
          $(window).on('onAfterAjaxUpdate', function(e){
            if (typeof $(attrs.compileOnChange)[0] !== 'undefined'){
              $compile(element)(scope);
              scope.$digest();
            }
          });
        })
      }
    }
  });

/**
 * @ngdoc directive
 * @name lsAngularApp.directive:compileOnClick
 * @description
 * # compileOnClick
 */
angular.module('lsAngularApp')
  .directive('compileOnClick', function ($window,$compile,$timeout,$rootScope) {
    return {
      restrict: 'A',
      link: function(scope,element,attrs,ctrl){
        element.on('click', function(){
          if ($rootScope.compiled.indexOf(attrs.compileOnClick) === -1){
            $rootScope.compiled.push(attrs.compileOnClick);
            $(window).on('onAfterAjaxUpdate', function(e){
              var $elem = $($(attrs.compileOnClick)[0]);
              if (typeof $elem !== 'undefined'){
                $timeout(function(){
                  var e = $(attrs.compileOnClick).contents();
                  $elem.empty().append($compile(e)(scope));
                });
              }
            });
          }
          else {
            console.warn('Already watching for Ajax updates to ' + attrs.compileOnClick);
          }
        })
      }
    }
  });


/**
 * @ngdoc directive
 * @name lsAngularApp.directive:watchChange
 * @description
 * # watchChange
 */
angular.module('lsAngularApp')
  .directive('watchChange', function ($window,$compile,$timeout) {
    return {
      restrict: 'A',
      require: 'ngModel',
      link: function(scope,element,attrs,ngModel){
        //watch the element for a model change, then trigger the .change() function so Lemonstand can update the product
        scope.$watch(function () {
           return ngModel.$modelValue;
        }, function(newValue,oldValue) {
            if (newValue !== oldValue){
              $timeout(function(){
                element.change();
              });
            }
        });
      }
    }
  });




/**
 * @ngdoc directive
 * @name lsAngularApp.directive:reloadAfterAjax
 * @description
 * # reloadAfterAjax
 */
angular.module('lsAngularApp')
  .directive('reloadAfterAjax', function ($window,$location,$rootScope) {
    return {
      restrict: 'A',
      link: function(scope,element,attrs){

        //the ajax update method provided by LemonStand breaks multiple Angular things, such as:
        // * Icon font
        // * Layout attributes (flexbox)
        // * Angular UI directives (checkboxes, etc.)

        element.on('click', function(){
          $(window).on('onAfterAjaxUpdate', function(e){
            $rootScope.pendingRefresh = true; //maybe show a loading spinner?
            $window.location.reload();
          });
        })
      }
    }
  });

/**
 * @ngdoc directive
 * @name lsAngularApp.directive:stars
 * @description
 * # stars
 */
angular.module('lsAngularApp')
  .directive('stars', function () {
    return {
      restrict: 'E',
      template: '<md-icon ng-repeat="star in stars track by $index" class="star icon-small" ng-class="{\'star-active\': star.filled }">[[ star.half ? \'star_half\' : \'star\']]</md-icon>',
      scope: {
          value: '=',
      },
      link: function (scope,element,attrs) {

        var generateStars = function(){
          scope.stars = [];
          if (attrs.value % 1 && (attrs.value % 1)*10 > 7){
            var whole = Math.ceil(attrs.value);
            var half = false;
          }
          else if ( attrs.value % 1 && (attrs.value % 1)*10 <= 7 ){
            var whole = Math.floor(attrs.value);
            var half = true;
          }
          else {
            var whole = Math.floor(attrs.value);
            var half = false;
          }
          var addedHalf = false;
          for (var i = 1; i <= 5; i++) {
              scope.stars.push({
                  filled: i <= Math.ceil(attrs.value),
                  half: whole < i && half && !addedHalf
              });

              if ( (i > whole) && half && !addedHalf ){
                addedHalf = true;
              }
          }
        };
        generateStars();

        scope.$watch('value',function(){
          generateStars();
        });

      }
    };
  });



/**
 * @ngdoc service
 * @name lsAngularApp.CartService
 * @description
 * # CartService
 * Service in the lsAngularApp.
 */
angular.module('lsAngularApp')
  .service('CartService', function ($q,$window,$rootScope,$filter) {

    var $ls = $window.localStorage;

    var cartUpdated = function(cart){ $rootScope.$emit('cartUpdated', cart); };
    var favsUpdated = function(favs){ $rootScope.$emit('favsUpdated', favs); };

    this.addToCart = function(product){
      var deferred = $q.defer();
      var cart = !angular.isUndefined($ls.cart) ? JSON.parse($ls.cart) : [];
      var inCart = this.isInCart(product);
      if ( !inCart ){ cart.push(product); }
      $ls.cart = JSON.stringify(cart);
      cartUpdated(cart);
      deferred.resolve(cart);
      return deferred.promise;
    };

    this.removeFromCart = function(product){
      var deferred = $q.defer();
      var cart = [];
      if (!angular.isUndefined($ls.cart)){
        cart = JSON.parse($ls.cart);
        var inCart = $filter('filter')( cart, { 'id': product.id }, true )[0];
        var index = window.indexOfObject(cart,inCart);
        if ( index !== -1 ){
          cart.splice(index,1);
          $ls.cart = JSON.stringify(cart);
          deferred.resolve(cart);
        }
        else {
          deferred.reject();
        }
      }
      else {
        deferred.reject();
      }
      cartUpdated(cart);
      return deferred.promise;
    };

    this.cart = function(){
      var cart = !angular.isUndefined($ls.cart) ? JSON.parse($ls.cart) : [];
      cartUpdated(cart);
      return cart;
    };

    this.getLsCart = function(){
      var deferred = $q.defer();
      var items = cartItems ? cartItems : [];
      deferred.resolve(items);
      return deferred.promise;
    }

    this.isInCart = function(product){
      var cart = !angular.isUndefined($ls.cart) ? JSON.parse($ls.cart) : [];
      var inCart = $filter('filter')( cart , { 'id': product.id }, true );
      return inCart.length ? true : false;
    };


    this.addFavourite = function(product){
      var deferred = $q.defer();
      var favs = !angular.isUndefined($ls.favourites) ? JSON.parse($ls.favourites) : [];
      var isFav = window.indexOfObject(favs,product);
      if ( isFav === -1 ){ favs.push(product); }
      $ls.favourites = JSON.stringify(favs);
      favsUpdated(favs);
      deferred.resolve(favs);
      return deferred.promise;
    };

    this.removeFavourite = function(product){
      var deferred = $q.defer();
      if (!angular.isUndefined($ls.favourites)){
        var favs = JSON.parse($ls.favourites);
        var isFav = $filter('filter')( favs, { 'id': product.id }, true )[0];
        var index = window.indexOfObject(favs,isFav);
        if ( index !== -1 ){
          favs.splice(index,1);
          $ls.favourites = JSON.stringify(favs);
          favsUpdated(favs);
          deferred.resolve(favs);
        }
        else {
          deferred.reject();
        }
      }
      else {
        deferred.reject();
      }
      return deferred.promise;
    };

    this.isFavourite = function(product){
      var favs = !angular.isUndefined($ls.favourites) ? JSON.parse($ls.favourites) : [];
      var isFav = $filter('filter')( favs , { 'id': product.id }, true );
      return isFav.length ? true : false;
    };

    this.favourites = function(){
      var favs = !angular.isUndefined($ls.favourites) ? JSON.parse($ls.favourites) : [];
      favsUpdated(favs);
      return favs;
    };



  });



/**
 * @ngdoc filter
 * @name lsAngularApp.filter:trailingZero
 * @function
 * @description
 * # trailingZero
 * Filter in the lsAngularApp.
 */
angular.module('lsAngularApp')
  .filter('trailingZero', function () {
    return function (input) {
      input = input % 1 !== 0 ? Math.floor( input ) + '.' + Math.floor((input % 1)*100) : input;
      return input;
    };
  });



/**
 * @ngdoc filter
 * @name lsAngularApp.filter:urlencode
 * @function
 * @description
 * # urlencode
 * Filter in the lsAngularApp.
 */
angular.module('lsAngularApp')
  .filter('urlencode', function ($window) {
    return function (input) {
      return $window.encodeURIComponent(input);
    };
  });

  $(window).on('onAjaxFailure', function(e,res){
    console.error(res);
  });

  $(window).on('onAjaxSuccess', function(e,res){
    console.log(res);
  });



  angular.module('lsAngularApp')
    .controller('CreditCardCtrl', function($scope,$locale) {
      $scope.currentYear = new Date().getFullYear();
      $scope.currentMonth = new Date().getMonth() + 1;
      $scope.months = $locale.DATETIME_FORMATS.MONTH;
      $scope.ccinfo = {type:undefined};
    });

  angular.module('lsAngularApp')
  .directive('creditCardType', function(){
    return {
      require: 'ngModel',
      link: function(scope, elm, attrs, ctrl){
        ctrl.$parsers.unshift(function(value){
          scope.ccinfo.type =
            (/^5[1-5]/.test(value)) ? 'MASTERCARD'
            : (/^4/.test(value)) ? 'VISA'
            : (/^3[47]/.test(value)) ? 'AMEX'
            // : (/^6011|65|64[4-9]|622(1(2[6-9]|[3-9]\d)|[2-8]\d{2}|9([01]\d|2[0-5]))/.test(value)) ? 'DISCOVER'
            : undefined;
          ctrl.$setValidity('invalid',!!scope.ccinfo.type)
          return value;
        })
      }
    };
  })

  angular.module('lsAngularApp')
    .directive('cardExpiration', function(){
      return {
        require: 'ngModel',
        link: function(scope, elm, attrs, ctrl){
          scope.$watch('[ccinfo.month,ccinfo.year]',function(value){
            ctrl.$setValidity('invalid',true);
            if ( scope.ccinfo.year == scope.currentYear && scope.ccinfo.month <= scope.currentMonth) {
              ctrl.$setValidity('invalid',false);
            }
            return value;
          },true);
        }
      };
    })

  angular.module('lsAngularApp')
    .filter('range', function() {
      return function(arr, lower, upper) {
        for (var i = lower; i <= upper; i++) {
          arr.push(i);
        }
        return arr;
      }
    })
